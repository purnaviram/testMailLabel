﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication3
{
    static class Constants
    {
        public const string InputFileName = "Input.xlsx";
        public const string TemplateFileName = "Template.docx";
        public const string tempFolderName = "TempFiles_tkk8888";
        public const string tempFilePrefix = "Temp_cd_"; // not being used

        public const string OutputFileName = "Output_Code.docx";

    }
}
