﻿using DataMatrix.net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using Word = Microsoft.Office.Interop.Word;
using System.Drawing;

namespace WindowsFormsApplication3
{
    class WordWriter
    {
        public void StartProcessing()
        {
            string temFilepath = @"C:\TestDoc\TempFiles";
            ExcelReader exl = new ExcelReader();
            List<Shipment> lst = exl.getAllItems("");

           
            //List<Shipment> lst = new List<Shipment>();
            //lst.Add(new Shipment
            //{
            //     ArticleId = "997963254383496091"
            //    ,Name = "Name hai 1"
            //    ,AddressL1 = "AddressHai1"
            //    ,AddressL2 = "AddressHai Line2"
            //    ,AddressL3 = "Address qwqw Lin3"
            //    ,AddressL4 = "AddressHai1 Line4"
            //    ,AddressL5 = "AddressHai1 Ln5"
            //    ,AddressL6 = "AddressHai1 Ln6"

            //    ,retAddressL1 = "RetAddress Line1"
            //    ,retAddressL2 = "RetAddress Line2"
            //    ,retAddressL3 = "RetAddress1 Line 3"
            //    ,retAddressL4 = "RetAddress1 Lin4"
            //    ,retAddressL5 = "RetAddress1 Lin5"                
            //    ,Order = "laptop *1"
            //    ,weight = "0.00001Kg"
            //    ,DeliveryIns1 = "IF PERMISES UNATTENDED, LEAVE IN A SECURE LOCATION1"
            //    ,DeliveryIns2 = "OUT OF THE WEATHER1"
            //});

            //lst.Add(new Shipment
            //{
            //     ArticleId = "334563276783496092"
            //    ,Name = "Aus hai 2"
            //    ,AddressL1 = "AddressHai2"
            //    ,AddressL2 = "AddressHai2 Line2"
            //    ,AddressL3 = "Address2 xyd Lin3"
            //    ,AddressL4 = "AddressHai2 Line4"
            //    ,AddressL5 = "AddressHai2 Ln5"
            //    ,AddressL6 = "AddressHai2 Ln6"

            //    ,retAddressL1 = "RetAddress2 Line1"
            //    ,retAddressL2 = "RetAddress2 Line2"
            //    ,retAddressL3 = "RetAddress2 Line 3"
            //    ,retAddressL4 = "RetAddress2 Lin4"
            //    ,retAddressL5 = "RetAddress2 Lin5"
            //    ,Order = "Hard disk *2"
            //    ,weight = "0.00002Kg"
            //    ,DeliveryIns1 = "IF PERMISES UNATTENDED, LEAVE IN A SECURE LOCATION2"
            //    ,DeliveryIns2 = "OUT OF THE WEATHER2"
            //});

            //lst.Add(new Shipment
            //{
            //     ArticleId = "786343233483496093"
            //    ,Name = "Chi hai 3"
            //    ,AddressL1 = "AddressHai3"
            //    ,AddressL2 = "AddressHai3 Line2"
            //    ,AddressL3 = "Address3 gtv Lin3"
            //    ,AddressL4 = "AddressHai3 Line4"
            //    ,AddressL5 = "AddressHai3 Ln5"
            //    ,AddressL6 = "AddressHai3 Ln6"

            //    ,retAddressL1 = "RetAddress3 Test Line1"
            //    ,retAddressL2 = "RetAddress3 Test Line2"
            //    ,retAddressL3 = "RetAddress3 Test Line3"
            //    ,retAddressL4 = "RetAddress3 Test Lin4"
            //    ,retAddressL5 = "RetAddress3 Test Lin5"
            //    ,Order = "Stock *3"
            //    ,weight = "0.00003Kg"
            //    ,DeliveryIns1 = "IF PERMISES UNATTENDED, LEAVE IN A SECURE LOCATION3"
            //    ,DeliveryIns2 = "OUT OF THE WEATHER3"
            //});
            //lst.Add(new Shipment
            //{
            //     ArticleId = "432343255783496094"
            //    ,Name = "Name hai 4"
            //    ,AddressL1 = "AddressHai4"
            //    ,AddressL2 = "AddressHai4 Line2"
            //    ,AddressL3 = "Address4 xyd Lin3"
            //    ,AddressL4 = "AddressHai4 Line4"
            //    ,AddressL5 = "AddressHai4 Ln5"
            //    ,AddressL6 = "AddressHai4 Ln6"

            //    ,retAddressL1 = "RetAddress4 Line1"
            //    ,retAddressL2 = "RetAddress4 Line2"
            //    ,retAddressL3 = "RetAddress4 Line 3"
            //    ,retAddressL4 = "RetAddress4 Lin4"
            //    ,retAddressL5 = "RetAddress4 Lin5"
            //    ,Order = "laptop *4"
            //    ,weight = "0.00004Kg"
            //    ,DeliveryIns1 = "IF PERMISES UNATTENDED, LEAVE IN A SECURE LOCATION4"
            //    ,DeliveryIns2 = "OUT OF THE WEATHER4"
            //});

            int order = 0;

            Word.Application wordApp = null;// new Word.Application();
            //wordApp.Visible = true;
            //wordApp.ShowAnimation = true;
            Object missing = Missing.Value;

            Word.Document writer = null;// wordApp.Documents.Add(@"C:\TestDoc\Template_3.0.docx");

            for (int i = 1; i <= lst.Count; i++)
            {
                if (i % 4 == 0)
                    order = 4;
                else
                    order = i % 4;

                if (order == 1)
                {
                    wordApp = new Word.Application();
                    wordApp.Visible = true;
                    wordApp.ShowAnimation = true;
                    writer = wordApp.Documents.Add(@"C:\TestDoc\Template_3.0.docx");
                }


                StartStep1(wordApp, writer, lst[i-1],order);

                if(order == 4 || i == lst.Count)
                {
                    writer.SaveAs2(@"C:\TestDoc\TempFiles\test_"+Guid.NewGuid()+".docx");
                    writer.Close(ref missing, ref missing, ref missing);
                    writer = null;
                    wordApp.Quit(ref missing, ref missing, ref missing);

                    wordApp = null;
                }
            }

            //Object fileName = @"C:\TestDoc\test.docx";
            //writer.SaveAs2(ref fileName);
            //writer.Close(ref missing, ref missing, ref missing);
            //writer = null;
            //wordApp.Quit(ref missing, ref missing, ref missing);

            //wordApp = null;

            MessageBox.Show("Document saved successfully");
        }        

        public void StartStep1(Word.Application wordApp, Word.Document writer, Shipment item, int order)
        {
            Image qrCode = getQRCode(item.ShipMentNo);
            Image barCode = getBarCoe(item.ShipMentNo);


            foreach (Word.InlineShape s in writer.InlineShapes)
            {
                if (s.Type == Microsoft.Office.Interop.Word.WdInlineShapeType.wdInlineShapePicture)
                {
                    //if ((s.AlternativeText == "Q1" || s.AlternativeText == "Q2" || s.AlternativeText == "Q3" || s.AlternativeText == "Q4"))
                    if ((s.AlternativeText == "Q" + order.ToString()))
                    {

                        //s.Delete();
                        s.Reset();
                        Clipboard.SetDataObject(qrCode);
                        s.Range.Paste();
                        s.Height = 52;
                        //s.Width = 70;
                    }

                    //if (s.AlternativeText == "Bar1" || s.AlternativeText == "Bar2" || s.AlternativeText == "Bar3" || s.AlternativeText == "Bar4")// || s.AlternativeText == "Q2" || s.AlternativeText == "Q3" || s.AlternativeText == "Q4")
                    if (s.AlternativeText == "Bar" + order.ToString())
                    {
                        s.Reset();
                        Clipboard.SetDataObject(barCode);
                        s.Range.Paste();
                    }
                }
            }

            FindAndReplace(wordApp, "<NAME"+order.ToString()+">", item.Name);

            FindAndReplace(wordApp, "<AL" + order.ToString() + "1>", item.AddressL1);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "2>", item.AddressL2);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "3>", item.AddressL3);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "4>", item.AddressL4);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "5>", item.AddressL5);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "6>", item.AddressL6);

            FindAndReplace(wordApp, "<DI" + order.ToString() + "1>", item.DeliveryIns1);
            //FindAndReplace(wordApp, "<DI" + order.ToString() + "2>", item.DeliveryIns2);

            FindAndReplace(wordApp, "<W" + order.ToString() + ">", item.weight);

            FindAndReplace(wordApp, "<CON" + order.ToString() + ">", item.ConNo);

            FindAndReplace(wordApp, "<ARTID" + order.ToString() + "1>", item.ArticleId);
            FindAndReplace(wordApp, "<ARTID" + order.ToString() + "2>", item.ArticleId);

            FindAndReplace(wordApp, "<Ret" + order.ToString() + "1>", item.retAddressL1);
            //FindAndReplace(wordApp, "<Ret" + order.ToString() + "2>", item.retAddressL2);
            //FindAndReplace(wordApp, "<Ret" + order.ToString() + "3>", item.retAddressL3);
            //FindAndReplace(wordApp, "<Ret" + order.ToString() + "4>", item.retAddressL4);
            //FindAndReplace(wordApp, "<Ret" + order.ToString() + "5>", item.retAddressL5);


            FindAndReplace(wordApp, "<Order" + order.ToString() + ">", item.Order);
                                     

            

        }

        public Image getQRCode (string text)
        {
            DmtxImageEncoder encoder = new DmtxImageEncoder();
            DmtxImageEncoderOptions options = new DmtxImageEncoderOptions();
            options.BackColor = Color.White;
            options.ForeColor = Color.Black;
            options.ModuleSize = 10;
            options.MarginSize = 0;
            //options.SizeIdx = DmtxSymbolSize.DmtxSymbolSquareAuto;
            return encoder.EncodeImage(text, options);
        }

        public Image getBarCoe(string text)
        {
            Zen.Barcode.Code128BarcodeDraw barcode = Zen.Barcode.BarcodeDrawFactory.Code128WithChecksum;
            //            pictureBox2.Image = barcode.Draw(textBox1.Text, 100);
            return barcode.Draw(text, 193, 3);
        }

        public void DoTextFormatting(Word.Application wapp)
        {
            FindAndReplace(wapp, "<NAME1>", "Ram prasad");
            FindAndReplace(wapp, "<NAME2>", "Lakshman prasad");
            FindAndReplace(wapp, "<NAME3>", "Bharat prasad");
            FindAndReplace(wapp, "<NAME4>", "Shatrughan prasad");

            FindAndReplace(wapp, "<ADDRESS1>", "Address1 \n AddressLine2 \n Addressline3 \n Country"); 
            FindAndReplace(wapp, "<ADDRESS2>", "Address2 \n AddressLine2 \n Addressline3 \n Country"); 
            FindAndReplace(wapp, "<ADDRESS3>", "Address3 \n AddressLine2 \n Addressline3 \n Country");
            FindAndReplace(wapp, "<ADDRESS4>", "Address4 \n AddressLine2 \n Addressline3 \n Country"); 
        }

        private void FindAndReplace(Microsoft.Office.Interop.Word.Application WordApp, object findText, object replaceWithText)
        {
            object matchCase = true;
            object matchWholeWord = true;
            object matchWildCards = false;
            object matchSoundsLike = false;
            object nmatchAllWordForms = false;
            //object forward = true;
            object forward = false;
            object format = false;
            object matchKashida = false;
            object matchDiacritics = false;
            object matchAlefHamza = false;
            object matchControl = false;
            object read_only = false;
            object visible = true;
            object replace = 2;
            object wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindContinue;
            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            WordApp.Selection.Find.Execute(ref findText, ref matchCase, ref matchWholeWord, ref matchWildCards, ref matchSoundsLike,
            ref nmatchAllWordForms, ref forward,
            ref wrap, ref format, ref replaceWithText,
            ref replaceAll, ref matchKashida,
            ref matchDiacritics, ref matchAlefHamza,
            ref matchControl);
        }
    }


}
