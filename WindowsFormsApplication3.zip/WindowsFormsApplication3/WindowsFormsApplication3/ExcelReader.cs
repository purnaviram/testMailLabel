﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace WindowsFormsApplication3
{
    class ExcelReader
    {

        public List<Shipment> getAllItems(string folderUrl)
        {
            List<Shipment> itemList = new List<Shipment>();
            //Create COM Objects. Create a COM object for everything that is referenced
            Excel.Application xlApp = new Excel.Application();
            //Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(@"C:\TestDoc\Input_3.0.xlsx");
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(Path.Combine(folderUrl,Constants.InputFileName));
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];
            Excel.Range xlRange = xlWorksheet.UsedRange;

            int rowCount = xlRange.Rows.Count;
            int colCount = 18;//xlRange.Columns.Count;

            if (rowCount > 501)
            {
                rowCount = 501;
            }

            for (int i = 2; i <= rowCount; i++)
            {

                // if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                //   Console.Write(xlRange.Cells[i, j].Value2.ToString() + "\t");

                if (xlRange.Cells[i, 1] == null || xlRange.Cells[i, 1].Text == null || xlRange.Cells[i, 1].Text == "")
                {
                    break;
                }
                else
                {
                    Shipment obj = new Shipment();
                    obj.Id                 = xlRange.Cells[i,  1].Text;
                    obj.ArticleId          = xlRange.Cells[i,  2].Text;
                    obj.Name               = xlRange.Cells[i,  3].Text;
                    obj.AddressL1          = xlRange.Cells[i, 4].Text; ;// xlRange.Cells[i,  8].Text;
                    //obj.AddressL2          = xlRange.Cells[i,  9].Text;
                    //obj.AddressL3          = xlRange.Cells[i, 10].Text;
                    //obj.AddressL4          = xlRange.Cells[i, 11].Text;
                    //obj.AddressL5          = xlRange.Cells[i, 12].Text;
                    //obj.AddressL6          = xlRange.Cells[i, 13].Text;
                    obj.retAddressL1       = xlRange.Cells[i, 5].Text; // xlRange.Cells[i, 14].Text;
                    //obj.retAddressL2       = xlRange.Cells[i, 15].Text;
                    //obj.retAddressL3       = xlRange.Cells[i, 16].Text;
                    //obj.retAddressL4       = xlRange.Cells[i, 17].Text;
                    //obj.retAddressL5       = xlRange.Cells[i, 18].Text;
                    obj.Order              = xlRange.Cells[i,  6].Text;
                    obj.weight             = xlRange.Cells[i,  7].Text;
                    obj.DeliveryIns1       = xlRange.Cells[i,  8].Text;
                    //obj.DeliveryIns2       = xlRange.Cells[i,  7].Text;

                    itemList.Add(obj);                              
                }

               

                //for (int j = 1; j <= colCount; j++)
                //{
                //    //new line
                //    if (j == 1)
                //        Console.Write("\r\n");

                    //    //write the value to the console
                    //    if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null)
                    //        Console.Write(xlRange.Cells[i, j].Value2.ToString() + "\t");


                    //}
            }

            //release com objects to fully kill excel process from running in the background
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);

            //close and release
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);

            //quit and release
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);

            return itemList;
        }
    }
}
