﻿using DataMatrix.net;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

      
        /// <summary>
        /// trying to replace images here
        /// </summary>
        private void docWriter6(Image qrImg1, Image barImg1)
        {
            //Lnk1: https://www.youtube.com/watch?v=vkrfRwwtxsmIo4
            //Lnk2: https://docs.microsoft.com/en-us/visualstudio/vsto/how-to-programmatically-insert-text-into-word-documents?view=vs-2017
            //Lnk3: https://support.microsoft.com/en-us/help/316384/how-to-automate-microsoft-word-to-create-a-new-document-by-using-visua

            Word.Application wordApp = new Word.Application();

            wordApp.Visible = true;
            wordApp.ShowAnimation = true;
            Object missing = Missing.Value;

            Word.Document writer = wordApp.Documents.Add(@"C:\TestDoc\F21_Img.docx");

            List<Word.Range> ranges = new List<Microsoft.Office.Interop.Word.Range>();

            if (true)
            {

                foreach (Word.InlineShape s in writer.InlineShapes)
                {
                    if (s.Type == Microsoft.Office.Interop.Word.WdInlineShapeType.wdInlineShapePicture)
                    {
                        if ((s.AlternativeText == "Q1" || s.AlternativeText == "Q2" || s.AlternativeText == "Q3" || s.AlternativeText == "Q4"))
                        {
                           
                            //s.Delete();
                            s.Reset();
                            Clipboard.SetDataObject(qrImg1);
                            
                            s.Range.Paste();
                            s.Height = 52;
                            //s.Width = 70;
                        }

                        if (s.AlternativeText == "Bar1" || s.AlternativeText == "Bar2" || s.AlternativeText == "Bar3" || s.AlternativeText == "Bar4")// || s.AlternativeText == "Q2" || s.AlternativeText == "Q3" || s.AlternativeText == "Q4")
                        {                           
                            s.Reset();
                            Clipboard.SetDataObject(barImg1);
                            s.Range.Paste();
                        }
                    }
                }
              
            }

            //WordApp.Quit(ref yes, ref missing, ref missing);

            //////////////////////////////////////////////////
            WordWriter wrt = new WordWriter();
            wrt.DoTextFormatting(wordApp);
            


            Object fileName = @"C:\TestDoc\test.docx";
            writer.SaveAs2(ref fileName);
            writer.Close(ref missing, ref missing, ref missing);
            writer = null;
            wordApp.Quit(ref missing, ref missing, ref missing);

            wordApp = null;

            MessageBox.Show("Document saved successfully");
        }


        /// <summary>
        /// trying to replace image in range
        /// </summary>
        private void docWriter5(Image qrImg1,Image barImg1)
        {
            //Lnk1: https://www.youtube.com/watch?v=vkrfRwwtxsmIo4
            //Lnk2: https://docs.microsoft.com/en-us/visualstudio/vsto/how-to-programmatically-insert-text-into-word-documents?view=vs-2017
            //Lnk3: https://support.microsoft.com/en-us/help/316384/how-to-automate-microsoft-word-to-create-a-new-document-by-using-visua

            Word.Application wordApp = new Word.Application();

            wordApp.Visible = true;
            wordApp.ShowAnimation = true;
            Object missing = Missing.Value;

            Word.Document writer = wordApp.Documents.Add(@"C:\TestDoc\F21_Img.docx");

            List<Word.Range> ranges = new List<Microsoft.Office.Interop.Word.Range>();

            if (true)
            {

                foreach (Word.InlineShape s in writer.InlineShapes)
                {
                    if (s.Type == Microsoft.Office.Interop.Word.WdInlineShapeType.wdInlineShapePicture)
                    {
                        if (s.AlternativeText == "Q1")// || s.AlternativeText == "Q2" || s.AlternativeText == "Q3" || s.AlternativeText == "Q4")
                        {
                            
                            ranges.Add(s.Range);
                            s.Delete();
                            //s.Reset();
                            //Clipboard.SetDataObject(qrImg1);
                            //s.Range.Paste();
                        }

                        //if (s.AlternativeText == "Bar11")// || s.AlternativeText == "Q2" || s.AlternativeText == "Q3" || s.AlternativeText == "Q4")
                        //{
                        //    ranges.Add(s.Range);
                        //    // s.Delete();
                        //    s.Reset();
                        //    Clipboard.SetDataObject(barImg1);
                        //    s.Range.Paste();
                        //}
                    }
                }
                foreach (Word.Range r in ranges)
                {
                   
                    Clipboard.SetDataObject(qrImg1);
                    r.Paste();    
                    
                    
                }
            }

            //WordApp.Quit(ref yes, ref missing, ref missing);

            //////////////////////////////////////////////////




            Object fileName = @"C:\TestDoc\test.docx";
            writer.SaveAs2(ref fileName);
            writer.Close(ref missing, ref missing, ref missing);
            writer = null;
            wordApp.Quit(ref missing, ref missing, ref missing);

            wordApp = null;

            MessageBox.Show("Document saved successfully");
        }


        /// <summary>
        /// Merges the multiple docs and delets the blank sections
        /// </summary>
        private void docWriter4()
        {
            //Lnk1: https://www.youtube.com/watch?v=vkrfRwwtxsmIo4
            //Lnk2: https://docs.microsoft.com/en-us/visualstudio/vsto/how-to-programmatically-insert-text-into-word-documents?view=vs-2017
            //Lnk3: https://support.microsoft.com/en-us/help/316384/how-to-automate-microsoft-word-to-create-a-new-document-by-using-visua

            Word.Application wordApp = new Word.Application();

            wordApp.Visible = true;
            wordApp.ShowAnimation = true;
            Object missing = Missing.Value;


            Word.Document writer = wordApp.Documents.Add(@"C:\TestDoc\F21.docx");

            //Word.Document writer = wordApp.Documents.Add(
            //                            ref missing
            //                          , ref missing
            //                          , ref missing
            //                          , ref missing);

            Word.Selection selection = wordApp.Selection;


            object pageBreak = Word.WdBreakType.wdPageBreak;// wdPageBreak;// wdSectionBreakNextPage;

            //selection.InsertBreak(ref pageBreak);

            selection.InsertNewPage();
            selection.InsertFile(@"C:\TestDoc\F22.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);


            //selection.InsertBreak(ref pageBreak);

            selection.InsertNewPage();
            selection.InsertFile(@"C:\TestDoc\F23.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);

            //selection.InsertBreak(ref pageBreak);

            selection.InsertNewPage();
            selection.InsertFile(@"C:\TestDoc\F24.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);

            //selection.InsertNewPage();


            //selection.InsertBreak(ref pageBreak);

            //selection.InsertFile(@"C:\TestDoc\TKK8888_OutputTemplate.dotx"
            //                            , ref missing
            //                            , ref missing
            //                            , ref missing
            //                            , ref missing);

            if (true)
            {
                Word.Paragraphs paragraphs = writer.Paragraphs;
                foreach (Word.Paragraph paragraph in paragraphs)
                {
                    if (paragraph.Range.Text.Trim() == string.Empty)
                    {
                        paragraph.Range.Select();
                        wordApp.Selection.Delete();
                    }
                }
            }


            Object fileName = @"C:\TestDoc\test.docx";
            writer.SaveAs2(ref fileName);
            writer.Close(ref missing, ref missing, ref missing);
            writer = null;
            wordApp.Quit(ref missing, ref missing, ref missing);

            wordApp = null;

            MessageBox.Show("Document saved successfully");
        }

        private void docWriter3()
        {
            //Lnk1: https://www.youtube.com/watch?v=vkrfRwwtxsmIo4
            //Lnk2: https://docs.microsoft.com/en-us/visualstudio/vsto/how-to-programmatically-insert-text-into-word-documents?view=vs-2017
            //Lnk3: https://support.microsoft.com/en-us/help/316384/how-to-automate-microsoft-word-to-create-a-new-document-by-using-visua

            Word.Application wordApp = new Word.Application();

            wordApp.Visible = false;
            wordApp.ShowAnimation = false;
            Object missing = Missing.Value;


            Word.Document writer = wordApp.Documents.Add(@"C:\TestDoc\F21.docx");

            //Word.Document writer = wordApp.Documents.Add(
            //                            ref missing
            //                          , ref missing
            //                          , ref missing
            //                          , ref missing);

            Word.Selection selection = wordApp.Selection;






            object pageBreak = Word.WdBreakType.wdPageBreak;// wdPageBreak;// wdSectionBreakNextPage;

            //selection.InsertBreak(ref pageBreak);

            selection.InsertNewPage();
            selection.InsertFile(@"C:\TestDoc\F22.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);


            //selection.InsertBreak(ref pageBreak);

            selection.InsertNewPage();
            selection.InsertFile(@"C:\TestDoc\F23.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);

            //selection.InsertBreak(ref pageBreak);

            selection.InsertNewPage();
            selection.InsertFile(@"C:\TestDoc\F24.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);

            //selection.InsertBreak(ref pageBreak);

            //selection.InsertFile(@"C:\TestDoc\TKK8888_OutputTemplate.dotx"
            //                            , ref missing
            //                            , ref missing
            //                            , ref missing
            //                            , ref missing);


            Object fileName = @"C:\TestDoc\test.docx";
            writer.SaveAs2(ref fileName);
            writer.Close(ref missing, ref missing, ref missing);
            writer = null;
            wordApp.Quit(ref missing, ref missing, ref missing);

            wordApp = null;

            MessageBox.Show("Document saved successfully");
        }

        private void docWriter2()
        {
            //Lnk1: https://www.youtube.com/watch?v=vkrfRwwtxsmIo4
            //Lnk2: https://docs.microsoft.com/en-us/visualstudio/vsto/how-to-programmatically-insert-text-into-word-documents?view=vs-2017
            //Lnk3: https://support.microsoft.com/en-us/help/316384/how-to-automate-microsoft-word-to-create-a-new-document-by-using-visua

            Word.Application wordApp = new Word.Application();

            wordApp.Visible = false;
            wordApp.ShowAnimation = false;
            Object missing = Missing.Value;


            Word.Document writer = wordApp.Documents.Add(@"C:\TestDoc\TKK8888_OutputTemplate.docx");

            //Word.Document writer = wordApp.Documents.Add(
            //                            ref missing
            //                          , ref missing
            //                          , ref missing
            //                          , ref missing);

            Word.Selection selection = wordApp.Selection;






            object pageBreak = Word.WdBreakType.wdSectionBreakNextPage;// wdPageBreak;// wdSectionBreakNextPage;

            selection.InsertBreak(ref pageBreak);


            selection.InsertFile(@"C:\TestDoc\TKQ.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);


            selection.InsertBreak(ref pageBreak);


            selection.InsertFile(@"C:\TestDoc\TKQ3.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);

            //selection.InsertBreak(ref pageBreak);

            //selection.InsertFile(@"C:\TestDoc\TKK8888_OutputTemplate.dotx"
            //                            , ref missing
            //                            , ref missing
            //                            , ref missing
            //                            , ref missing);


            Object fileName = @"C:\TestDoc\test.docx";
            writer.SaveAs2(ref fileName);
            writer.Close(ref missing, ref missing, ref missing);
            writer = null;
            wordApp.Quit(ref missing, ref missing, ref missing);

            wordApp = null;

            MessageBox.Show("Document saved successfully");
        }

        private void docWriter1()
        {
            //Lnk1: https://www.youtube.com/watch?v=vkrfRwwtxsmIo4
            //Lnk2: https://docs.microsoft.com/en-us/visualstudio/vsto/how-to-programmatically-insert-text-into-word-documents?view=vs-2017
            //Lnk3: https://support.microsoft.com/en-us/help/316384/how-to-automate-microsoft-word-to-create-a-new-document-by-using-visua

            Word.Application wordApp = new Word.Application();

            wordApp.Visible = false;
            wordApp.ShowAnimation = false;
            Object missing = Missing.Value;

            Word.Document writer = wordApp.Documents.Add(
                                        ref missing
                                      , ref missing
                                      , ref missing
                                      , ref missing);

            Word.Selection selection = wordApp.Selection;



           


            object pageBreak = Word.WdBreakType.wdSectionBreakNextPage;


            selection.InsertFile(@"C:\TestDoc\TKK8888_OutputTemplate.dotx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);

            selection.InsertBreak(ref pageBreak);

            selection.InsertFile(@"C:\TestDoc\TKK8888_OutputTemplate.dotx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);

            //writer.Words.Last.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
            //writer.Content.SetRange(0, 0);
            Object fileName = @"C:\TestDoc\test.docx";
            writer.SaveAs2(ref fileName);
            writer.Close(ref missing, ref missing, ref missing);
            writer = null;
            wordApp.Quit(ref missing, ref missing, ref missing);

            wordApp = null;

            MessageBox.Show("Document saved successfully");
        }

        private void docWriter()
        {
            //Lnk1: https://www.youtube.com/watch?v=vkrfRwwtxsmIo4
            //Lnk2: https://docs.microsoft.com/en-us/visualstudio/vsto/how-to-programmatically-insert-text-into-word-documents?view=vs-2017
            //Lnk3: https://support.microsoft.com/en-us/help/316384/how-to-automate-microsoft-word-to-create-a-new-document-by-using-visua

             Word.Application wordApp = new Word.Application();
            //Word.ApplicationClass wordApp = new Word.ApplicationClass();

            wordApp.Visible = false;
            wordApp.ShowAnimation = false;
            Object missing = Missing.Value;

            //Word.Document writer = wordApp.Documents.Add(ref missing, ref missing, ref missing, ref missing);
            //Word.Document writer = wordApp.Documents.Add(@"C:\TestDoc\TKK8888_OutputTemplate.dotx");
            //Word.Document writer = wordApp.Documents.Add(@"C:\TestDoc\TKK8888_OutputTemplate.docx");

            Word.Document writer = wordApp.Documents.Add(ref missing, ref missing, ref missing, ref missing);
            object start = 0;
            object end = 0;

            

            Word.Range rnf = writer.Range(ref missing, ref missing);
            rnf.InsertFile(@"C:\TestDoc\TKK8888_OutputTemplate.dotx", ref missing, ref missing, ref missing, ref missing);

            start = wordApp.ActiveDocument.Content.End - 1;

            Word.Range rng1 = writer.Range(ref start, ref missing);
            rng1.InsertFile(@"C:\TestDoc\TKK8888_OutputTemplate.dotx", ref missing, ref missing, ref missing, ref missing);

            start = wordApp.ActiveDocument.Content.End - 1;

            //writer.Words.Last.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
            //writer.Content.SetRange(0, 0);



            Word.Document writer2 = wordApp.Documents.Add(@"C:\TestDoc\TKK8888_OutputTemplate.docx");
;
            //writer.Content.Text += writer2.Content.Text;
            //
            //writer2.Close();
            //writer2 = null;

            // writer.Content.SetRange(0, 0);
            //writer.Content.Text = "Hello Boss \nGood Boss";



            //writer.Words.Last.InsertBreak(Word.WdBreakType.wdPageBreak);
            //
            //writer.Content.SetRange(0, 0);
            //writer.Content.Text += "Page 2\nHello Boss \nBad Boss";

            //  writer.Words.Last.InsertBreak(Word.WdBreakType.wdSectionBreakNextPage);
            //
            //  writer.Content.SetRange(0, 0);
            //  writer.Content.Text += "Page 3\nHello Boss \nBad Boss";

            //Object fileName = "@C:\TestDoc\test.docx";
            Object fileName = @"C:\TestDoc\test.docx";
            writer.SaveAs2(ref fileName);
            writer.Close(ref missing, ref missing, ref missing);
            writer = null;
            wordApp.Quit(ref missing, ref missing, ref missing);
            
            wordApp = null;

            MessageBox.Show("Document saved successfully"); 
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            WordWriter obj = new WordWriter();
            obj.StartProcessing();
        }

        private void folderBrowserDialog2_HelpRequest(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string path = "";
            //FolderBrowserDialog fbd = new FolderBrowserDialog();
            //fbd.SelectedPath = System.Environment.CurrentDirectory;

            

            //if(fbd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                if (folderBrowserDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {

                imgOutputOk.Visible = false;
                txtLog.Text = "";

                path = folderBrowserDialog1.SelectedPath;
                folderUrl.Text = path;

                if(!File.Exists(Path.Combine(path, Constants.InputFileName)))
                {
                    MessageBox.Show("Input file missing");
                    IsFileFailure();
                    return;

                }

                if (!File.Exists(Path.Combine(path, Constants.TemplateFileName)))
                {
                    MessageBox.Show("Template file missing");
                    IsFileFailure();
                    return;
                }

                IsFileSuccess();
                

            }
            else
            {
                IsFileFailure();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        public void IsFileSuccess()
        {
            imgFileNo.Visible = false;
            imgFileOk.Visible = true;

        }

        public void IsFileFailure()
        {
            imgFileNo.Visible = true;
            imgFileOk.Visible = false;
            
        }

        //private void button5_Click(object sender, EventArgs e)
        //{

        //}

        private void btnOutput_Click(object sender, EventArgs e)
        {
            if (imgFileOk.Visible == true)
            {
                //try
               // {
                    txtLog.Text = "";
                    imgOutputOk.Visible = false;
                    lblProcessing.Text = "Processing....";
                    lblProcessing.Visible = true;

                    WordWriter_L obj = new WordWriter_L();
                    //obj.MergeDocuments();
                    lblOutput.Text = obj.StartProcessing(folderUrl.Text, false,txtLog);
                    imgOutputOk.Visible = true;

                    lblProcessing.Text = "";
                    lblProcessing.Visible = false;
                //}
                //catch(Exception ex)
                //{
                //    txtLog.Text = ex.InnerException.Message.ToString();
                //    imgOutputOk.Visible = false;
                //    lblProcessing.Text = "Error occured, Please try again.";
                //    lblProcessing.Visible = true;
                //}

            }
            else
            {

                MessageBox.Show("Please complete the step1.");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtURL.Visible = false;
            btnChangeLoc.Visible = false;
            string path = folderUrl.Text;
            if (!File.Exists(Path.Combine(path, Constants.InputFileName)))
            {

                IsFileFailure();
                return;

            }

            if (!File.Exists(Path.Combine(path, Constants.TemplateFileName)))
            {
                IsFileFailure();
                return;
            }

            IsFileSuccess();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            string path = txtURL.Text;            

            if (!File.Exists(Path.Combine(path, Constants.InputFileName)))
            {
                MessageBox.Show("Input file missing");
                IsFileFailure();
                return;

            }

            if (!File.Exists(Path.Combine(path, Constants.TemplateFileName)))
            {
                MessageBox.Show("Template file missing");
                IsFileFailure();
                return;
            }

            IsFileSuccess();
        }

     
    }
}
