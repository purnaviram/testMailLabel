﻿using DataMatrix.net;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using Word = Microsoft.Office.Interop.Word;
using System.Drawing;
using System.IO;
using Aspose.BarCode;
using Aspose.BarCode.Generation;

namespace WindowsFormsApplication3
{
    class WordWriter_L
    {
        public Form1 myForm;// = new Form1();
        public string MergeDocuments(string folderPath, List<string> lstTempFile,bool seeDocProgress)
        {

            Word.Application wordApp = new Word.Application();

            wordApp.Visible = seeDocProgress;
            //wordApp.ShowAnimation = Seerogress;
            Object missing = Missing.Value;
            Object objBreak = Word.WdBreakType.wdPageBreak;
            Object objUnit = Word.WdUnits.wdStory;
            Word.Selection selection = null;
                        
            object pageBreak = Word.WdBreakType.wdSectionBreakNextPage; //wdPageBreak

            Word.Document writer = null;

            if (lstTempFile.Count > 0)
            {
                writer = wordApp.Documents.Add(lstTempFile[0]);
                selection = wordApp.Selection;
                wordApp.Selection.EndKey(ref objUnit, ref missing);
                selection.InsertBreak(ref pageBreak);
            }


            for (int i = 1; i < lstTempFile.Count; i++)
            {
                selection.InsertFile(lstTempFile[i]
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);

                wordApp.Selection.EndKey(ref objUnit, ref missing);
            }

    
        

            if (false)
            {
                Word.Paragraphs paragraphs = writer.Paragraphs;
                foreach (Word.Paragraph paragraph in paragraphs)
                {
                    if (paragraph.Range.Text.Trim() == string.Empty)
                    {
                        paragraph.Range.Select();
                        wordApp.Selection.Delete();
                    }
                }
            }


            Object fileName = Path.Combine(folderPath, Constants.OutputFileName);
            writer.SaveAs2(ref fileName);
            writer.Close(ref missing, ref missing, ref missing);
            writer = null;
            wordApp.Quit(ref missing, ref missing, ref missing);

            wordApp = null;

            //MessageBox.Show("Out put Document saved successfully here: " + fileName);
            return fileName.ToString();
        }

        public void MergeDocuments_Backup()
        {
            //Lnk1: https://www.youtube.com/watch?v=vkrfRwwtxsmIo4
            //Lnk2: https://docs.microsoft.com/en-us/visualstudio/vsto/how-to-programmatically-insert-text-into-word-documents?view=vs-2017
            //Lnk3: https://support.microsoft.com/en-us/help/316384/how-to-automate-microsoft-word-to-create-a-new-document-by-using-visua

            Word.Application wordApp = new Word.Application();

            wordApp.Visible = true;
            //wordApp.ShowAnimation = true;
            Object missing = Missing.Value;


            Word.Document writer = wordApp.Documents.Add(@"C:\TestDoc\F21.docx");

            //Word.Document writer = wordApp.Documents.Add(
            //                            ref missing
            //                          , ref missing
            //                          , ref missing
            //                          , ref missing);

            Object objBreak = Word.WdBreakType.wdPageBreak;
            Object objUnit = Word.WdUnits.wdStory;

            

            wordApp.Selection.EndKey(ref objUnit, ref missing);



            Word.Selection selection = wordApp.Selection;


            //object pageBreak = Word.WdBreakType.wdPageBreak;// wdPageBreak;// wdSectionBreakNextPage;
            object pageBreak1 = Word.WdBreakType.wdSectionBreakNextPage; //Word.WdBreakType.wdSectionBreakNextPage;

            //selection.InsertBreak(ref pageBreak);
            selection.InsertBreak(ref pageBreak1);

            //selection.InsertNewPage();
            selection.InsertFile(@"C:\TestDoc\F22.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);


            wordApp.Selection.EndKey(ref objUnit, ref missing);

            //selection.InsertBreak(ref pageBreak);
            //selection.InsertBreak(ref pageBreak1);

            //selection.InsertNewPage();
            selection.InsertFile(@"C:\TestDoc\F23.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);


            wordApp.Selection.EndKey(ref objUnit, ref missing);

            //selection.InsertBreak(ref pageBreak);
            //selection.InsertBreak(ref pageBreak1);

            //selection.InsertNewPage();
            selection.InsertFile(@"C:\TestDoc\F24.docx"
                                        , ref missing
                                        , ref missing
                                        , ref missing
                                        , ref missing);

            //selection.InsertNewPage();


            //selection.InsertBreak(ref pageBreak);

            //selection.InsertFile(@"C:\TestDoc\TKK8888_OutputTemplate.dotx"
            //                            , ref missing
            //                            , ref missing
            //                            , ref missing
            //                            , ref missing);

            if (true)
            {
                Word.Paragraphs paragraphs = writer.Paragraphs;
                foreach (Word.Paragraph paragraph in paragraphs)
                {
                    if (paragraph.Range.Text.Trim() == string.Empty)
                    {
                        paragraph.Range.Select();
                        wordApp.Selection.Delete();
                    }
                }
            }


            Object fileName = @"C:\TestDoc\test_Merge.docx";
            writer.SaveAs2(ref fileName);
            writer.Close(ref missing, ref missing, ref missing);
            writer = null;
            wordApp.Quit(ref missing, ref missing, ref missing);

            wordApp = null;

            MessageBox.Show("Document saved successfully");
        }

        public void ClearTempFolder(string temFilepath)
        {
            System.IO.DirectoryInfo di = new DirectoryInfo(temFilepath);
            if (Directory.Exists(temFilepath))
            {
                foreach (FileInfo file in di.GetFiles())
                {
                    file.Delete();
                }
            }
            else
            {
                Directory.CreateDirectory(temFilepath);
            }
           
        }

        public void updateLog(TextBox txtLog, string value)
        {
            txtLog.Text = value + Environment.NewLine + txtLog.Text;
        }
        public string StartProcessing(string folderUrl, bool seeDocProgress, TextBox txtLog)
        {
            updateLog(txtLog, "Started Prcessing!");


            string temFilepath = Path.Combine(folderUrl, Constants.tempFolderName);
            int fileName = 1;
            List<string> lstAllTempFile = new List<string>();
            ClearTempFolder(temFilepath);

            updateLog(txtLog, "Reading Input file");

            ExcelReader exl = new ExcelReader();
            List<Shipment> lst = exl.getAllItems(folderUrl);

            updateLog(txtLog,  "Tota records found for processing: "+ lst.Count.ToString());

            int order = 0;

            Word.Application wordApp = null;// new Word.Application();
            //wordApp.Visible = true;
            //wordApp.ShowAnimation = true;
            Object missing = Missing.Value;

            Word.Document writer = null;// wordApp.Documents.Add(@"C:\TestDoc\Template_3.0.docx");

            for (int i = 1; i <= lst.Count; i++)
            {
                if (i % 4 == 0)
                    order = 4;
                else
                    order = i % 4;

                if (order == 1)
                {
                    wordApp = new Word.Application();
                    wordApp.Visible = seeDocProgress;
                    //wordApp.ShowAnimation = Seerogress;
                    //writer = wordApp.Documents.Add(@"C:\TestDoc\Template_3.0.docx");
                    writer = wordApp.Documents.Add(Path.Combine(folderUrl, Constants.TemplateFileName));
                }


                StartStep1(temFilepath,wordApp, writer, lst[i - 1], order);

                if (order == 4 || i == lst.Count)
                {
                    //writer.SaveAs2(@"C:\TestDoc\TempFiles\test_"+Guid.NewGuid()+".docx");//fileName
                    writer.SaveAs2(Path.Combine(temFilepath, fileName.ToString() + ".docx"));//fileName

                    lstAllTempFile.Add(Path.Combine(temFilepath, fileName.ToString() + ".docx"));

                    writer.Close(ref missing, ref missing, ref missing);
                    writer = null;
                    wordApp.Quit(ref missing, ref missing, ref missing);
                    wordApp = null;
                    fileName++;
                }

                updateLog(txtLog, "completed record no: "+ i.ToString()) ;
            }

            updateLog(txtLog, "Consolidating all records");
            string output= MergeDocuments(folderUrl, lstAllTempFile, seeDocProgress);
            updateLog(txtLog, "Processing complted successfully!");
            return output;
        }        

        public void StartStep1(string tempPath,Word.Application wordApp, Word.Document writer, Shipment item, int order)
        {
            
            Image qrCode = getQRCode(item.ShipMentNo);
            Image barCode = getAsposeBarCoe(tempPath,item.GS1_128_codeText); //getBarCoe(item.ShipMentNo);


            foreach (Word.InlineShape s in writer.InlineShapes)
            {
                if (s.Type == Microsoft.Office.Interop.Word.WdInlineShapeType.wdInlineShapePicture)
                {
                    //if ((s.AlternativeText == "Q1" || s.AlternativeText == "Q2" || s.AlternativeText == "Q3" || s.AlternativeText == "Q4"))
                    if ((s.AlternativeText == "Q" + order.ToString()))
                    {

                        //s.Delete();
                        s.Reset();
                        Clipboard.SetDataObject(qrCode);
                        s.Range.Paste();
                        s.Height = 52;
                        //s.Width = 70;
                    }

                    //if (s.AlternativeText == "Bar1" || s.AlternativeText == "Bar2" || s.AlternativeText == "Bar3" || s.AlternativeText == "Bar4")// || s.AlternativeText == "Q2" || s.AlternativeText == "Q3" || s.AlternativeText == "Q4")
                    if (s.AlternativeText == "Bar" + order.ToString())
                    {
                        s.Reset();
                        Clipboard.SetDataObject(barCode);
                        s.Range.Paste();
                    }
                }
            }

            FindAndReplace(wordApp, "<NAME"+order.ToString()+">", item.Name);

            FindAndReplace(wordApp, "<AL" + order.ToString() + "1>", item.AddressL1);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "2>", item.AddressL2);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "3>", item.AddressL3);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "4>", item.AddressL4);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "5>", item.AddressL5);
            //FindAndReplace(wordApp, "<AL" + order.ToString() + "6>", item.AddressL6);

            FindAndReplace(wordApp, "<DI" + order.ToString() + "1>", item.DeliveryIns1);
            //FindAndReplace(wordApp, "<DI" + order.ToString() + "2>", item.DeliveryIns2);

            FindAndReplace(wordApp, "<W" + order.ToString() + ">", item.weight);

            FindAndReplace(wordApp, "<CON" + order.ToString() + ">", item.ConNo);

            FindAndReplace(wordApp, "<ARTID" + order.ToString() + "1>", item.ArticleId);
            FindAndReplace(wordApp, "<ARTID" + order.ToString() + "2>", item.ArticleId);

            FindAndReplace(wordApp, "<Ret" + order.ToString() + "1>", item.retAddressL1);
            //FindAndReplace(wordApp, "<Ret" + order.ToString() + "2>", item.retAddressL2);
            //FindAndReplace(wordApp, "<Ret" + order.ToString() + "3>", item.retAddressL3);
            //FindAndReplace(wordApp, "<Ret" + order.ToString() + "4>", item.retAddressL4);
            //FindAndReplace(wordApp, "<Ret" + order.ToString() + "5>", item.retAddressL5);


            FindAndReplace(wordApp, "<Order" + order.ToString() + ">", item.Order);


            qrCode.Dispose();
            barCode.Dispose();

        }

        public Image getQRCode (string text)
        {
            DmtxImageEncoder encoder = new DmtxImageEncoder();
            DmtxImageEncoderOptions options = new DmtxImageEncoderOptions();
            options.BackColor = Color.White;
            options.ForeColor = Color.Black;
            options.ModuleSize = 10;
            options.MarginSize = 0;
            //options.SizeIdx = DmtxSymbolSize.DmtxSymbolSquareAuto;
            return encoder.EncodeImage(text, options);
        }

        public Image getBarCoe(string text)
        {
            Zen.Barcode.Code128BarcodeDraw barcode = Zen.Barcode.BarcodeDrawFactory.Code128WithChecksum;
            //            pictureBox2.Image = barcode.Draw(textBox1.Text, 100);
            return barcode.Draw(text, 193, 3);
        }

        public Image getAsposeBarCoe(string tempPath,string text)
        {
            //BarCodeGenerator generator = new BarCodeGenerator(Aspose.BarCode.Generation.EncodeTypes.GS1Code128, "(00)"+ text);
            //BarCodeGenerator generator = new BarCodeGenerator(Aspose.BarCode.Generation.EncodeTypes.GS1Code128,  text);
             
            string LData = "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz4NCjxMaWNlbnNlPg0KICAgIDxEYXRhPg0KICAgICAgICA8TGljZW5zZWRUbz5pckRldmVsb3BlcnMuY29tPC9MaWNlbnNlZFRvPg0KICAgICAgICA8RW1haWxUbz5pbmZvQGlyRGV2ZWxvcGVycy5jb208L0VtYWlsVG8+DQogICAgICAgIDxMaWNlbnNlVHlwZT5EZXZlbG9wZXIgT0VNPC9MaWNlbnNlVHlwZT4NCiAgICAgICAgPExpY2Vuc2VOb3RlPkxpbWl0ZWQgdG8gMTAwMCBkZXZlbG9wZXIsIHVubGltaXRlZCBwaHlzaWNhbCBsb2NhdGlvbnM8L0xpY2Vuc2VOb3RlPg0KICAgICAgICA8T3JkZXJJRD43ODQzMzY0Nzc4NTwvT3JkZXJJRD4NCiAgICAgICAgPFVzZXJJRD4xMTk0NDkyNDM3OTwvVXNlcklEPg0KICAgICAgICA8T0VNPlRoaXMgaXMgYSByZWRpc3RyaWJ1dGFibGUgbGljZW5zZTwvT0VNPg0KICAgICAgICA8UHJvZHVjdHM+DQogICAgICAgICAgICA8UHJvZHVjdD5Bc3Bvc2UuVG90YWwgUHJvZHVjdCBGYW1pbHk8L1Byb2R1Y3Q+DQogICAgICAgIDwvUHJvZHVjdHM+DQogICAgICAgIDxFZGl0aW9uVHlwZT5FbnRlcnByaXNlPC9FZGl0aW9uVHlwZT4NCiAgICAgICAgPFNlcmlhbE51bWJlcj57RjJCOTcwNDUtMUIyOS00QjNGLUJENTMtNjAxRUZGQTE1QUE5fTwvU2VyaWFsTnVtYmVyPg0KICAgICAgICA8U3Vic2NyaXB0aW9uRXhwaXJ5PjIwOTkxMjMxPC9TdWJzY3JpcHRpb25FeHBpcnk+DQogICAgICAgIDxMaWNlbnNlVmVyc2lvbj4zLjA8L0xpY2Vuc2VWZXJzaW9uPg0KICAgIDwvRGF0YT4NCiAgICA8U2lnbmF0dXJlPlFYTndiM05sTGxSdmRHRnNMb1B5YjJSMVkzUWdSbUZ0YVd4NTwvU2lnbmF0dXJlPg0KPC9MaWNlbnNlPg==";

            Stream stream = new MemoryStream(Convert.FromBase64String(LData));
            //Ex:
            stream.Seek(0, SeekOrigin.Begin);
            new Aspose.BarCode.License().SetLicense(stream);

            Guid newid = Guid.NewGuid();
            string imgPath = Path.Combine(tempPath, newid + "." + BarCodeImageFormat.Jpeg.ToString()); 

            using (BarCodeBuilder b = new BarCodeBuilder())
            {
                b.CodeText = text;// "(01)99312650999998(91)997963241383496090";
                //b.CaptionBelow = new Aspose.BarCode.Caption("B");
                //b.CaptionAbove = new Aspose.BarCode.Caption("A");
                b.CaptionBelow.Visible = false;
                b.CaptionAbove.Visible = false;

                b.Margins.Bottom = 0f;
                b.Margins.Top = 0.0f;
                
                //b.Margins.Left = 0.0f;
                b.BarHeight = 37.0f;//  .setHeight(32.0f);
                b.EncodeType = EncodeTypes.GS1Code128;
                b.CodeTextColor = Color.White;

                b.CodeTextSpace = 0f;
                b.CodeLocation = CodeLocation.None;


                b.Save(Path.Combine(@"C:\MailLabelFiles\TempFiles_tkk8888\", newid + "." + BarCodeImageFormat.Jpeg.ToString()));
            }

            return new Bitmap(Path.Combine(@"C:\MailLabelFiles\TempFiles_tkk8888\", newid + "." + BarCodeImageFormat.Jpeg.ToString()));
        }

        public void DoTextFormatting(Word.Application wapp)
        {
            FindAndReplace(wapp, "<NAME1>", "Ram prasad");
            FindAndReplace(wapp, "<NAME2>", "Lakshman prasad");
            FindAndReplace(wapp, "<NAME3>", "Bharat prasad");
            FindAndReplace(wapp, "<NAME4>", "Shatrughan prasad");

            FindAndReplace(wapp, "<ADDRESS1>", "Address1 \n AddressLine2 \n Addressline3 \n Country"); 
            FindAndReplace(wapp, "<ADDRESS2>", "Address2 \n AddressLine2 \n Addressline3 \n Country"); 
            FindAndReplace(wapp, "<ADDRESS3>", "Address3 \n AddressLine2 \n Addressline3 \n Country");
            FindAndReplace(wapp, "<ADDRESS4>", "Address4 \n AddressLine2 \n Addressline3 \n Country"); 
        }

        private void FindAndReplace(Microsoft.Office.Interop.Word.Application WordApp, object findText, object replaceWithText)
        {
            object matchCase = true;
            object matchWholeWord = true;
            object matchWildCards = false;
            object matchSoundsLike = false;
            object nmatchAllWordForms = false;
            //object forward = true;
            object forward = false;
            object format = false;
            object matchKashida = false;
            object matchDiacritics = false;
            object matchAlefHamza = false;
            object matchControl = false;
            object read_only = false;
            object visible = true;
            object replace = 2;
            object wrap = Microsoft.Office.Interop.Word.WdFindWrap.wdFindContinue;
            object replaceAll = Microsoft.Office.Interop.Word.WdReplace.wdReplaceAll;
            WordApp.Selection.Find.Execute(ref findText, ref matchCase, ref matchWholeWord, ref matchWildCards, ref matchSoundsLike,
            ref nmatchAllWordForms, ref forward,
            ref wrap, ref format, ref replaceWithText,
            ref replaceAll, ref matchKashida,
            ref matchDiacritics, ref matchAlefHamza,
            ref matchControl);
        }
    }


}
