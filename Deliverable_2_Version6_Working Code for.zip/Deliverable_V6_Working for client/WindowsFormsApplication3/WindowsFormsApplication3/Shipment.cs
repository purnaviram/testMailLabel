﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication3
{
    class Shipment
    {
        //019931265099999891997963241383496090

        public string Id;
        public string ArticleId; ////997963241383496090
        public string constantCode = "019931265099999891";
        public string AICode = "(01)99312650999998(91)";

        public string GS1_128_codeText
        {
            get
            {
                return AICode + ArticleId;
            }

        }
        public string ConNo //9979632413
        {
            get
            {
                return ArticleId.Substring(0, 10); ;
            }            

        }

        public string ShipMentNo
        {
            get
            {
                return constantCode + ArticleId;
            }
        }

        public string Order;

        public string weight;

        public string DeliveryIns1;
        //public string DeliveryIns2;


        public string Name;
        public string AddressL1;
        //public string AddressL2;
        //public string AddressL3;
        //public string AddressL4;
        //public string AddressL5;
        //public string AddressL6;

        public string retAddressL1;
        //public string retAddressL2;
        //public string retAddressL3;
        //public string retAddressL4;
        //public string retAddressL5;

        
    }
}
